hxttps://documenter.getpostman.com/view/10808728/SzS8rjbc#7934d316-f751-4914-9909-39f1901caeb8

https://www.digitalocean.com/community/tutorials/react-axios-react

https://documenter.getpostman.com/view/11238297/SzfDwQdd?version=latest

#sources

- https://blogs.mulesoft.com/dev-guides/track-covid-19/

- https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_objects/Object/values

- https://www.programmableweb.com/api/covid19india-rest-api-v10

- https://api.covid19india.org/data.json

* https://blog.postman.com/how-to-build-an-api-based-covid-19-vaccine-locator/

* https://apisetu.gov.in/public/marketplace/api/cowin

* https://www.indiatoday.in/coronavirus-outbreak/vaccine-updates/story/covid-vaccine-registration-automation-stirs-debate-on-vaccine-equity-1800235-2021-05-08

* https://rapidapi.com/blog/news-app-react/

## news

- https://rapidapi.com/microsoft-azure-org-microsoft-cognitive-services/api/bing-news-search1
